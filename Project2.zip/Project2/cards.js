//J.Proctor
//04/13/2020
//CGS2829.OM1

//Image arrays
//Array for cards
var cardsArray = new Array();
//48 total
cardsArray[0] = new Image();
cardsArray[0].src = 'images/card_1.png';
cardsArray[1] = new Image();
cardsArray[1].src = 'images/card_1.png';

cardsArray[2] = new Image();
cardsArray[2].src = 'images/card_2.png';
cardsArray[3] = new Image();
cardsArray[3].src = 'images/card_2.png';

cardsArray[4] = new Image();
cardsArray[4].src = 'images/card_3.png';
cardsArray[5] = new Image();
cardsArray[5].src = 'images/card_3.png';

cardsArray[6] = new Image();
cardsArray[6].src = 'images/card_4.png';
cardsArray[7] = new Image();
cardsArray[7].src = 'images/card_4.png';

cardsArray[8] = new Image();
cardsArray[8].src = 'images/card_5.png';
cardsArray[9] = new Image();
cardsArray[9].src = 'images/card_5.png';

cardsArray[10] = new Image();
cardsArray[10].src = 'images/card_6.png';
cardsArray[11] = new Image();
cardsArray[11].src = 'images/card_6.png';

cardsArray[12] = new Image();
cardsArray[12].src = 'images/card_7.png';
cardsArray[13] = new Image();
cardsArray[13].src = 'images/card_7.png';

cardsArray[14] = new Image();
cardsArray[14].src = 'images/card_8.png';
cardsArray[15] = new Image();
cardsArray[15].src = 'images/card_8.png';

cardsArray[16] = new Image();
cardsArray[16].src = 'images/card_9.png';
cardsArray[17] = new Image();
cardsArray[17].src = 'images/card_9.png';

cardsArray[18] = new Image();
cardsArray[18].src = 'images/card_10.png';
cardsArray[19] = new Image();
cardsArray[19].src = 'images/card_10.png';

cardsArray[20] = new Image();
cardsArray[20].src = 'images/card_11.png';
cardsArray[21] = new Image();
cardsArray[21].src = 'images/card_11.png';

cardsArray[22] = new Image();
cardsArray[22].src = 'images/card_12.png';
cardsArray[23] = new Image();
cardsArray[23].src = 'images/card_12.png';

cardsArray[24] = new Image();
cardsArray[24].src = 'images/card_13.png';
cardsArray[25] = new Image();
cardsArray[25].src = 'images/card_13.png';

cardsArray[26] = new Image();
cardsArray[26].src = 'images/card_14.png';
cardsArray[27] = new Image();
cardsArray[27].src = 'images/card_14.png';

cardsArray[28] = new Image();
cardsArray[28].src = 'images/card_15.png';
cardsArray[29] = new Image();
cardsArray[29].src = 'images/card_15.png';

cardsArray[30] = new Image();
cardsArray[30].src = 'images/card_16.png';
cardsArray[31] = new Image();
cardsArray[31].src = 'images/card_16.png';

cardsArray[32] = new Image();
cardsArray[32].src = 'images/card_17.png';
cardsArray[33] = new Image();
cardsArray[33].src = 'images/card_17.png';

cardsArray[34] = new Image();
cardsArray[34].src = 'images/card_18.png';
cardsArray[35] = new Image();
cardsArray[35].src = 'images/card_18.png';

cardsArray[36] = new Image();
cardsArray[36].src = 'images/card_19.png';
cardsArray[37] = new Image();
cardsArray[37].src = 'images/card_19.png';

cardsArray[38] = new Image();
cardsArray[38].src = 'images/card_20.png';
cardsArray[39] = new Image();
cardsArray[39].src = 'images/card_20.png';

cardsArray[40] = new Image();
cardsArray[40].src = 'images/card_21.png';
cardsArray[41] = new Image();
cardsArray[41].src = 'images/card_21.png';

cardsArray[42] = new Image();
cardsArray[42].src = 'images/card_22.png';
cardsArray[43] = new Image();
cardsArray[43].src = 'images/card_22.png';

cardsArray[44] = new Image();
cardsArray[44].src = 'images/card_23.png';
cardsArray[45] = new Image();
cardsArray[45].src = 'images/card_23.png';

cardsArray[46] = new Image();
cardsArray[46].src = 'images/card_24.png';
cardsArray[47] = new Image();
cardsArray[47].src = 'images/card_24.png';

//Deck arrays, arrays are randomized and specified to each grouping 8, 16, 24 etc
var deckArray = new Array();

function numberCards(){
    if (num_cards = '48'){

        }
    else if (num_cards = '40'){
        
    }
    else if (num_cards = '32'){
        
    }
    else if (num_cards = '24'){
        
    }
    else if (num_cards = '16'){
        
    }
    else if (num_cards = '8'){
        
    }
}
    
//Functions