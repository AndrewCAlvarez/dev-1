//Jake Proctor
//04/25/2020
//CGS2829.OM1
//Walker
//Objective: Add objects to namespace either under the longer namespaces or under aliases
//Objective: Create a settings object that keeps track of the player name and number of images used for the the game. Object should contain functions that save the data to and retrive it from session storage. Able to create the settings object with an object literal. Add public methods that increment the integer variables, check if all the cards have been removed from the board, and calculate percentage of correct selections. The new methods should replace code that previously worked directly with the integer variables.
var settings = {
	getNumberOfImages: function() {
		return this.parseInt(sessionStorage.numberOfImages) || 24;
	},	

	setNumberOfImages: function(num) {
		this.sessionStorage.numberOfImages = num;
	},
		
	setPlayerName: function(name) {
		this.sessionStorage.playerName = name;
	},

	getPlayerName: function() {
		return this.sessionStorage.playerName || "";
	}
};