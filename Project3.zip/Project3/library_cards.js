//Jake Proctor
//04/25/2020
//CGS2829.OM1
//Walker
//Objective: Add objects to namespace either under the longer namespaces or under aliases
//Objective: Create a cards object that works with the cards. this object should contain the functions that preload and store images, store the src attributes for the cards, create the HTML for the cards, flip a card using a fade effect, and flip a card using a slide effect. Because the first two of these functions should be in private, use an IIFE and the module pattern to create the cards object. Additionally, modify the application so instead of strings throughout the application to specify the src attributes for the card back and the blank card, these attributes are stored in variables in this library. These variables should be in private state for protection,  but outside code should be able to access them via read-only properties. The read-only property should also be used to get the number of images that's stored in a variable in private state by the function in private state that creates the card images.
"use strict";
$(document).ready(function() {
	 var cards = {
		 //Preload and store Image objects for cards in images array
		 preloadAndStoreImages: (function() {
			 var numberOfImages = getNumberOfImages(); // get value from settings
			 var images = [];
			 var back = new Image();
			 back.src = "images/back.png";    
			 var blank = new Image();
			 blank.src = "images/blank.png";

			 for (var i = 1; i <= numberOfImages; i++) { // use value from settings
				 var img = new Image();
				 img.src = "images/card_" + i + ".png";
				 images.push(img);
			 }
			 return images;
		})(),
		 // store two src strings for each Image object in cards array
		 storeCardSrcs: (function(images) {
			 var srcs = [];
			 if (Array.isArray(images)) {
				 for (var i in images) {
					 srcs.push(images[i].src);
					 srcs.push(images[i].src);
				 }
			 }
			 return srcs;
		})(),

		 createCardsHtml: function(cards, backSrc) {
			 var counter, max, cardIndex, src, html;

			 // set initial counter value and max cards per row
			 counter = 1, max = 8;

			 // create cards HTML
			 if (Array.isArray(cards)) {
				 html = "<div>"; // open first div tag

				 while (cards.length > 0) {
					 // randomly select card from array
					 cardIndex = Math.floor(Math.random() * cards.length);
					 src = cards[cardIndex];
					 cards.splice(cardIndex, 1); // remove card from array

					 // create HTML for link and image
					 html += "<a id='" + src + "' href='#'><img src='" + backSrc + "' alt=''></a>";

					 // if end of row, clear float, close div tag and open new div tag, and reset counter
					 if (counter === max) {
						 html += "<p class='clear'></p></div><div>";
						 counter = 1;
					 } else { // otherwise, increment counter
						 counter++;
					 }
				 }
				 html+= "</div>"; // close last div tag
			 }
			 return html;
		},

		 fadeCardFlip: function(img, newSrc, duration) {
			 img.fadeOut(duration, function() {
				 img.attr( "src", newSrc ).fadeIn(duration);
			 });
		},

		 slideCardFlip: function(img, newSrc, duration) {
			 img.slideUp(duration, function() {
				 img.attr( "src", newSrc ).fadeIn(duration);
			 });
		}
	 };
}