//Jake Proctor
//04/25/2020
//CGS2829.OM1
//Walker
//Objective: Add objects to namespace either under the longer namespaces or under aliases
//Objective: Create scores object that keeps track of scores for each game as well as each player's high score. Object should contain two integer variables that keep track of the number of turns and the number of turns that result in a match. object should also contain functions that save scores to and retrieve them from local storage, compare scores, and display a player's high score. Integer values and functions that work with local storage should be in a private state, use an IIFE and module pattern to create scores object.
"use strict";
$(document).ready(function() {
	var scores = {
		getHighScore: function(name) {
			var percentage = localStorage.getItem(name) || undefined;
			return parseInt(percentage);
		},

		setHighScore: function(name, percentage) {
			if (name && name !== "" && !isNaN(percentage)) {
				localStorage.setItem(name, percentage);
			}
		},

		compareScores: function(name, percentage) {
			if (name && name !== "" && !isNaN(percentage)) {
				var highScore = getHighScore(name);
				if (isNaN(highScore) || percentage > highScore) {
					setHighScore(name, percentage);
				}
			}
		},

		displayHighScore: function(name) {
			if (name !== "") {
				var percent = getHighScore(name);
				if (!isNaN(percent)) {
					$("#high_score").text( "High score: " + percent + "%");
				}
			}
		}
	};
	
	var name, percent;
};